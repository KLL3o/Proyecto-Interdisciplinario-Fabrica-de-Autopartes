/**
 * 
 */
/**
 * @author Redes-04
 *
 */
module Proyecto {
}