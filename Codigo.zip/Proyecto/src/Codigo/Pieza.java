package Codigo;

public class Pieza {
	private String Nombre;
	private String Numero_Serie;
	public Pieza(String Nombre, String Numero_Serie) {
	 this.Nombre = Nombre;
	 this.Numero_Serie = Numero_Serie;
	}
	
	public String getNombre() {
	 return Nombre;
	}
	
	public void setFecha(String Nombre) {
	 this.Nombre = Nombre;
	}
	
	public String getNumero_Serie() {
	 return Numero_Serie;
	}
	
	public void setNumero_Serie(String Numero_Serie) {
	 this.Numero_Serie = Numero_Serie;
	}
	
	public void Asignar_Material(){}
	
	public void Registrar_Fabricacion(){}
}