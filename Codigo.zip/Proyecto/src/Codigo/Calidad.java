package Codigo;

import java.util.Date;

public class Calidad {
	private Date Fecha_Control;
	private String Resultado;
	public Calidad(Date Fecha_Control, String Resultado) {
	 this.Fecha_Control = Fecha_Control;
	 this.Resultado = Resultado;
	}
	
	public Date getFecha_Control() {
	 return Fecha_Control;
	}
	
	public void setFecha_Control(Date Fecha_Control) {
	 this.Fecha_Control = Fecha_Control;
	}
	
	public String getResultado() {
	 return Resultado;
	}
	
	public void setResultado(String Resultado) {
	 this.Resultado = Resultado;
	}

	public void Realizar_Control(){}
	
	public void Generar_Informe(){}
}