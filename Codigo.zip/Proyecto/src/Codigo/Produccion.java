package Codigo;

import java.util.Date;

public class Produccion {
	private Date Fecha;
	private int Cantidad_Producida;
	public Produccion(Date Fecha, int Cantidad_Producida) {
	 this.Fecha = Fecha;
	 this.Cantidad_Producida = Cantidad_Producida;
	}
	
	public Date getFecha() {
	 return Fecha;
	}
	
	public void setFecha(Date Fecha) {
	 this.Fecha = Fecha;
	}
	
	public int getCantidad_Producida() {
	 return Cantidad_Producida;
	}
	
	public void setCantidad_Producida(int Cantidad_Producida) {
	 this.Cantidad_Producida = Cantidad_Producida;
	}
	
	public void Inciar_Produccion(){}
	
	public void Registrar_Cantidad(){}
	
	public void Finalizar_Produccion(){}
	
}