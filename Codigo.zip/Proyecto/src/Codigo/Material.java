package Codigo;

public class Material{
	private String Nombre;
	private String Tipo;
	private int Stock;
	public Material(String Nombre, String Tipo, int Stock) {
	 this.Nombre = Nombre;
	 this.Tipo = Tipo;
	 this.Stock = Stock;
	}
	
	public String getNombre() {
	 return Nombre;
	}
	
	public void setNombre(String Nombre) {
	 this.Nombre = Nombre;
	}
	
	public String getTipo() {
	 return Tipo;
	}
	
	public void setTipo(String Tipo) {
	 this.Tipo = Tipo;
	}

	public int getStock() {
		 return Stock;
	}
		
	public void setStock(int Stock) {
		 this.Stock = Stock;
	}
	
	public void Actualizar_Stock(){}
	
	public void Consumir(){}
	
	public void Reponer(){}
	
}