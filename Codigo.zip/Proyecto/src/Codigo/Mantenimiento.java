package Codigo;

import java.util.Date;

public class Mantenimiento {
	private Date Fecha;
	private String Tipo;
	private int Descripcion;
	public Mantenimiento(Date Fecha, String Tipo, int Descripcion) {
	 this.Fecha = Fecha;
	 this.Tipo = Tipo;
	 this.Descripcion = Descripcion;
	}
	
	public Date getFecha() {
	 return Fecha;
	}
	
	public void setFecha(Date Fecha) {
	 this.Fecha = Fecha;
	}
	
	public String getTipo() {
	 return Tipo;
	}
	
	public void setTipo(String Tipo) {
	 this.Tipo = Tipo;
	}

	public int getDescripcion() {
		 return Descripcion;
	}
		
	public void setDescripcion(int Descripcion) {
		 this.Descripcion = Descripcion;
	}
	
	public void Programar(){}
	
	public void Ejecutar(){}
	
	public void Cerrar_Tarea(){}
	
}