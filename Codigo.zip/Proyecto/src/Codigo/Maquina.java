package Codigo;

import java.util.Date;

public class Maquina {
	private String Nombre;
	private String Estado;
	private Date Fecha_Instalacion;
	public Maquina(String Nombre, String Estado, Date Fecha_Instalacion) {
	 this.Nombre = Nombre;
	 this.Estado = Estado;
	 this.Fecha_Instalacion = Fecha_Instalacion;
	}
	
	public String getNombre() {
	 return Nombre;
	}
	
	public void setNombre(String Nombre) {
	 this.Nombre = Nombre;
	}
	
	public String getEstado() {
	 return Estado;
	}
	
	public void setEstado(String Estado) {
	 this.Estado = Estado;
	}
	
	public Date getFecha_Instalacion() {
	 return Fecha_Instalacion;
	}
	
	public void setFecha_Instalacion(Date Fecha_Instalacion) {
	 this.Fecha_Instalacion = Fecha_Instalacion;
	}
	
	
	public void Inciar(){}
	
	public void Detener(){}
	
	public void Verificar_Estado(){}
	
}
