package Codigo;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        
        Maquina maquina1 = new Maquina("Prensa Hidráulica", "Detenida", new Date());
        Maquina maquina2 = new Maquina("Torno CNC", "En mantenimiento", new Date());

        Material acero = new Material("Acero 1045", "Metal", 500);
        Material pintura = new Material("Pintura Epoxi", "Químico", 120);

        Pieza pieza1 = new Pieza("Brazo Suspensión", "BRZ-001-A");

        Produccion produccionHoy = new Produccion(new Date(), 0);

        Mantenimiento mant1 = new Mantenimiento(new Date(), "Preventivo", 1234);

        Calidad control1 = new Calidad(new Date(), "Pendiente");

        
        maquina1.Inciar();
        maquina1.setEstado("En funcionamiento");

        acero.Consumir();     
        acero.setStock(480);  
        produccionHoy.Inciar_Produccion();
        produccionHoy.setCantidad_Producida(150);

        pieza1.Asignar_Material();
        pieza1.Registrar_Fabricacion();

        control1.Realizar_Control();
        control1.setResultado("Aprobado");

        produccionHoy.Finalizar_Produccion();

        mant1.Programar();
        mant1.Ejecutar();
        mant1.Cerrar_Tarea();

        maquina1.Detener();
        maquina1.setEstado("Detenida");

        System.out.println("Producción del día: " + produccionHoy.getCantidad_Producida());
        System.out.println("Resultado calidad: " + control1.getResultado());
        System.out.println("Stock de acero: " + acero.getStock());
        System.out.println("Estado máquina: " + maquina1.getEstado());
    }
}
